# _DSLAB

# LAB-1
1. Write a program to print the positions and values of the smallest and second smallest numbers of n numbers using arrays.
2. Write a program to print the positions and values of the largest and second largest numbers of n numbers using arrays.

 # LAB-2
3. Write a program to insert an element and delete
an element at specified positions in an array.
4. Write a program to insert and delete a number in an array that is already sorted.
5. Write a program to merge two unsorted arrays.

 # LAB-3
6. Write a program to search an element in a 1-D array using Linear Search and Binary Search
7. Write a program to input n numbers in an array and print the sum of only those whose tenth-place digit is divisible by 5.
