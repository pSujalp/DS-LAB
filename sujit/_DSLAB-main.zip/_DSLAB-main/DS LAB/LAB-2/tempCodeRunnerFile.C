 // for(int i=f_size;i<total;i++)
        // {
        //     int x;
        //     scanf("%d",&x);
        //     *(arr1+i)=x;
        // }